// && 練習
// 符合贈禮條件
// 必須同時符合以下兩個條件才贈禮
// 消費滿 500(含)
// 是 VIP
// 買到蛋糕，指定商品

let a = 600;
let isVip = true;
let buyCake = true;
console.log(a>=500 && isVip==true && buyCake==true);

// ||練習
// 小孩吃東西
// 只要冰箱有米飯或蘋果或牛奶任一，小朋友就願意進食

let hasRice = true;
let hasApple = false;
let hasMilk = false;

console.log(hasRice == true || hasApple == true || hasMilk == true);