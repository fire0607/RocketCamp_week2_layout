// **布林變數
let isWakeUp = true;
console.log(isWakeUp);
console.log(typeof isWakeUp);


// **字串轉數字(例如：要運算表單中填寫的數字)
let a = "1";
a = parseInt("34567");
console.log(a+1);

// **數字轉字串(例如：電話號碼 區碼+號碼)
let b = 1;
b = b.toString();
console.log(typeof b);
console.log(b+5);