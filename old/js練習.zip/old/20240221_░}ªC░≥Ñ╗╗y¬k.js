// 陣列 array 第一筆資料為0
// let colors = ["blue","red","black"];
// console.log(colors)

// let books = [5,10,15,100];
// console.log(books);


// 讀取陣列資料、了解陣列長度
// console.log(colors[0]);


//讀取陣列資料，並賦予新變數流程
// let likeColor = colors[2];
// console.log(likeColor);


// length 讀取陣列長度流程
// let colorsNum = colors.length;
// console.log(colorsNum);


// 陣列預設寫入資料 (允許空值)
let colors = [];
colors[0]="blue";
colors[1]="black";
colors[2]="pink";

colors[4]="yellow";

console.log(colors);
console.log(colors.length);

